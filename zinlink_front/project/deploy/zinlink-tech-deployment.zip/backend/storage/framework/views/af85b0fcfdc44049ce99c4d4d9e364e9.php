<?php $__env->startSection('title', 'Team Members - Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Team Members</h1>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-sm border p-6">
            <h2 class="text-lg font-semibold mb-4">Add New Member</h2>
            <form action="<?php echo e(route('admin.team.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 border rounded-lg" />
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                    <input type="text" name="role" class="w-full px-3 py-2 border rounded-lg" />
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                    <textarea name="bio" rows="4" class="w-full px-3 py-2 border rounded-lg"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Photo</label>
                    <input type="file" name="photo" accept="image/*" class="w-full px-3 py-2 border rounded-lg" />
                </div>
                <div class="grid grid-cols-2 gap-4 items-center">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Sort Order</label>
                        <input type="number" name="sort_order" value="0" class="w-full px-3 py-2 border rounded-lg" />
                    </div>
                    <div class="flex items-center gap-2 mt-6">
                        <input type="checkbox" name="is_active" id="is_active" checked class="rounded" />
                        <label for="is_active" class="text-sm text-gray-700">Active</label>
                    </div>
                </div>
                <div>
                    <button class="bg-blue-600 text-white px-6 py-2 rounded-lg">Add Member</button>
                </div>
            </form>
        </div>

        <div class="bg-white rounded-lg shadow-sm border p-6">
            <h2 class="text-lg font-semibold mb-4">Preview</h2>
            <p class="text-sm text-gray-600">New members will appear below after saving.</p>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-sm border p-6">
        <h2 class="text-lg font-semibold mb-4">All Members</h2>
        <table class="min-w-full divide-y divide-gray-200">
            <thead>
                <tr>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Photo</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order</th>
                    <th class="px-4 py-2"></th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-2">
                        <?php if($member->photo_url): ?>
                            <img src="<?php echo e(str_starts_with($member->photo_url, 'http') ? $member->photo_url : url('/storage/'.$member->photo_url)); ?>" alt="<?php echo e($member->name); ?>" class="w-12 h-12 object-cover rounded-full border" />
                        <?php else: ?>
                            <div class="w-12 h-12 rounded-full bg-gray-100 border"></div>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-2 font-semibold text-gray-900"><?php echo e($member->name); ?></td>
                    <td class="px-4 py-2 text-gray-600"><?php echo e($member->role); ?></td>
                    <td class="px-4 py-2">
                        <span class="inline-block px-2 py-1 rounded-full text-xs font-semibold <?php echo e($member->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'); ?>">
                            <?php echo e($member->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td class="px-4 py-2"><?php echo e($member->sort_order); ?></td>
                    <td class="px-4 py-2 text-right">
                        <form action="<?php echo e(route('admin.team.update', $member)); ?>" method="POST" enctype="multipart/form-data" class="inline-flex items-center gap-2">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="name" value="<?php echo e($member->name); ?>" class="px-2 py-1 border rounded" />
                            <input type="text" name="role" value="<?php echo e($member->role); ?>" class="px-2 py-1 border rounded" />
                            <input type="number" name="sort_order" value="<?php echo e($member->sort_order); ?>" class="w-20 px-2 py-1 border rounded" />
                            <input type="file" name="photo" class="px-2 py-1 border rounded" />
                            <label class="inline-flex items-center gap-1 text-sm">
                                <input type="checkbox" name="is_active" <?php echo e($member->is_active ? 'checked' : ''); ?> class="rounded" /> Active
                            </label>
                            <button class="px-3 py-1 bg-blue-600 text-white rounded">Save</button>
                        </form>
                        <form action="<?php echo e(route('admin.team.destroy', $member)); ?>" method="POST" class="inline-block ml-2" onsubmit="return confirm('Delete this member?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="px-3 py-1 bg-red-600 text-white rounded">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-6"><?php echo e($members->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/onyangozeddy/Desktop/zinlink poject/admin_zinlink/resources/views/admin/team/index.blade.php ENDPATH**/ ?>